<?php

/**
 * League.Uri (https://uri.thephpleague.com/components/2.0/)
 *
 * @package    League\Uri
 * @subpackage League\Uri\Components
 * @author     Ignace Nyamagana Butera <nyamsprod@gmail.com>
 * @link       https://github.com/thephpleague/uri-components
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */
declare (strict_types=1);
namespace GFPDF_Vendor\League\Uri\Components;

use Iterator;
use GFPDF_Vendor\League\Uri\Contracts\PathInterface;
use GFPDF_Vendor\League\Uri\Contracts\SegmentedPathInterface;
use GFPDF_Vendor\League\Uri\Contracts\UriComponentInterface;
use GFPDF_Vendor\League\Uri\Exceptions\OffsetOutOfBounds;
use GFPDF_Vendor\League\Uri\Exceptions\SyntaxError;
use TypeError;
use function array_count_values;
use function array_filter;
use function array_keys;
use function array_pop;
use function array_unshift;
use function count;
use function dirname;
use function end;
use function explode;
use function implode;
use function is_scalar;
use function ltrim;
use function method_exists;
use function rtrim;
use function sprintf;
use function str_replace;
use function strpos;
use function strrpos;
use function substr;
use const ARRAY_FILTER_USE_KEY;
use const FILTER_VALIDATE_INT;
use const PATHINFO_EXTENSION;
final class HierarchicalPath extends \GFPDF_Vendor\League\Uri\Components\Component implements \GFPDF_Vendor\League\Uri\Contracts\SegmentedPathInterface
{
    private const SEPARATOR = '/';
    /**
     * @var PathInterface
     */
    private $path;
    /**
     * @var string[]
     */
    private $segments;
    /**
     * @deprecated 2.3.0
     *
     * @see ::createFromString
     * @see ::createFromPath
     *
     * New instance.
     *
     * @param mixed|string $path
     */
    public function __construct($path = '')
    {
        if (!$path instanceof \GFPDF_Vendor\League\Uri\Contracts\PathInterface) {
            $path = new \GFPDF_Vendor\League\Uri\Components\Path($path);
        }
        $this->path = $path;
        $segments = (string) $this->decodeComponent($path->__toString());
        if ($this->path->isAbsolute()) {
            $segments = \substr($segments, 1);
        }
        $this->segments = \explode(self::SEPARATOR, $segments);
    }
    /**
     * Returns a new instance from an string or a stringable object.
     *
     * @param string|object $path
     */
    public static function createFromString($path = '') : self
    {
        return self::createFromPath(\GFPDF_Vendor\League\Uri\Components\Path::createFromString($path));
    }
    public static function createFromPath(\GFPDF_Vendor\League\Uri\Contracts\PathInterface $path) : self
    {
        return new self($path);
    }
    /**
     * {@inheritDoc}
     */
    public static function __set_state(array $properties) : self
    {
        return new self($properties['path']);
    }
    /**
     * Returns a new instance from an iterable structure.
     *
     * @throws TypeError If the segments are malformed
     */
    public static function createRelativeFromSegments(iterable $segments) : self
    {
        $pathSegments = [];
        foreach ($segments as $value) {
            if (!\is_scalar($value) && !\method_exists($value, '__toString')) {
                throw new \TypeError('The submitted segments are invalid.');
            }
            $pathSegments[] = (string) $value;
        }
        $path = \implode(self::SEPARATOR, $pathSegments);
        return new self(\ltrim($path, self::SEPARATOR));
    }
    /**
     * Returns a new instance from an iterable structure.
     *
     * @throws TypeError If the segments are malformed
     */
    public static function createAbsoluteFromSegments(iterable $segments) : self
    {
        $pathSegments = [];
        foreach ($segments as $value) {
            if (!\is_scalar($value) && !\method_exists($value, '__toString')) {
                throw new \TypeError('The submitted segments are invalid.');
            }
            $pathSegments[] = (string) $value;
        }
        $path = \implode(self::SEPARATOR, $pathSegments);
        if (self::SEPARATOR !== ($path[0] ?? '')) {
            return new self(self::SEPARATOR . $path);
        }
        return new self($path);
    }
    /**
     * Create a new instance from a URI object.
     *
     * @param mixed $uri an URI object
     *
     * @throws TypeError If the URI object is not supported
     */
    public static function createFromUri($uri) : self
    {
        return new self(\GFPDF_Vendor\League\Uri\Components\Path::createFromUri($uri));
    }
    /**
     * {@inheritDoc}
     */
    public function count() : int
    {
        return \count($this->segments);
    }
    /**
     * {@inheritDoc}
     */
    public function getIterator() : \Iterator
    {
        foreach ($this->segments as $segment) {
            (yield $segment);
        }
    }
    /**
     * {@inheritDoc}
     */
    public function isAbsolute() : bool
    {
        return $this->path->isAbsolute();
    }
    /**
     * {@inheritDoc}
     */
    public function hasTrailingSlash() : bool
    {
        return $this->path->hasTrailingSlash();
    }
    /**
     * {@inheritDoc}
     */
    public function getContent() : ?string
    {
        return $this->path->getContent();
    }
    /**
     * {@inheritDoc}
     */
    public function getUriComponent() : string
    {
        return (string) $this->getContent();
    }
    /**
     * {@inheritDoc}
     */
    public function decoded() : string
    {
        return $this->path->decoded();
    }
    /**
     * {@inheritDoc}
     */
    public function getDirname() : string
    {
        $path = (string) $this->decodeComponent($this->path->__toString());
        return \str_replace(['\\', "\0"], [self::SEPARATOR, '\\'], \dirname(\str_replace('\\', "\0", $path)));
    }
    /**
     * {@inheritDoc}
     */
    public function getBasename() : string
    {
        $data = $this->segments;
        return (string) \array_pop($data);
    }
    /**
     * {@inheritDoc}
     */
    public function getExtension() : string
    {
        [$basename] = \explode(';', $this->getBasename(), 2);
        return \pathinfo($basename, \PATHINFO_EXTENSION);
    }
    /**
     * {@inheritDoc}
     */
    public function get(int $offset) : ?string
    {
        if ($offset < 0) {
            $offset += \count($this->segments);
        }
        return $this->segments[$offset] ?? null;
    }
    /**
     * {@inheritDoc}
     */
    public function keys(?string $segment = null) : array
    {
        if (null === $segment) {
            return \array_keys($this->segments);
        }
        return \array_keys($this->segments, $segment, \true);
    }
    /**
     * {@inheritDoc}
     */
    public function segments() : array
    {
        return $this->segments;
    }
    /**
     * {@inheritDoc}
     */
    public function withoutDotSegments() : \GFPDF_Vendor\League\Uri\Contracts\PathInterface
    {
        $path = $this->path->withoutDotSegments();
        if ($path !== $this->path) {
            return new self($path);
        }
        return $this;
    }
    /**
     * {@inheritDoc}
     */
    public function withLeadingSlash() : \GFPDF_Vendor\League\Uri\Contracts\PathInterface
    {
        $path = $this->path->withLeadingSlash();
        if ($path !== $this->path) {
            return new self($path);
        }
        return $this;
    }
    /**
     * {@inheritDoc}
     */
    public function withoutLeadingSlash() : \GFPDF_Vendor\League\Uri\Contracts\PathInterface
    {
        $path = $this->path->withoutLeadingSlash();
        if ($path !== $this->path) {
            return new self($path);
        }
        return $this;
    }
    /**
     * {@inheritDoc}
     */
    public function withoutTrailingSlash() : \GFPDF_Vendor\League\Uri\Contracts\PathInterface
    {
        $path = $this->path->withoutTrailingSlash();
        if ($path !== $this->path) {
            return new self($path);
        }
        return $this;
    }
    /**
     * {@inheritDoc}
     */
    public function withTrailingSlash() : \GFPDF_Vendor\League\Uri\Contracts\PathInterface
    {
        $path = $this->path->withTrailingSlash();
        if ($path !== $this->path) {
            return new self($path);
        }
        return $this;
    }
    /**
     * {@inheritDoc}
     */
    public function withContent($content) : \GFPDF_Vendor\League\Uri\Contracts\UriComponentInterface
    {
        $content = self::filterComponent($content);
        if ($content === $this->path->getContent()) {
            return $this;
        }
        return new self($content);
    }
    /**
     * @param mixed|string $segment
     */
    public function append($segment) : \GFPDF_Vendor\League\Uri\Contracts\SegmentedPathInterface
    {
        $segment = self::filterComponent($segment);
        if (null === $segment) {
            throw new \TypeError('The appended path can not be null.');
        }
        return new self(\rtrim($this->path->__toString(), self::SEPARATOR) . self::SEPARATOR . \ltrim($segment, self::SEPARATOR));
    }
    /**
     * @param mixed|string $segment
     */
    public function prepend($segment) : \GFPDF_Vendor\League\Uri\Contracts\SegmentedPathInterface
    {
        $segment = self::filterComponent($segment);
        if (null === $segment) {
            throw new \TypeError('The prepended path can not be null.');
        }
        return new self(\rtrim($segment, self::SEPARATOR) . self::SEPARATOR . \ltrim($this->path->__toString(), self::SEPARATOR));
    }
    /**
     * @param mixed|string $segment
     */
    public function withSegment(int $key, $segment) : \GFPDF_Vendor\League\Uri\Contracts\SegmentedPathInterface
    {
        $nb_segments = \count($this->segments);
        if ($key < -$nb_segments - 1 || $key > $nb_segments) {
            throw new \GFPDF_Vendor\League\Uri\Exceptions\OffsetOutOfBounds(\sprintf('The given key `%s` is invalid.', $key));
        }
        if (0 > $key) {
            $key += $nb_segments;
        }
        if ($nb_segments === $key) {
            return $this->append($segment);
        }
        if (-1 === $key) {
            return $this->prepend($segment);
        }
        if (!$segment instanceof \GFPDF_Vendor\League\Uri\Contracts\PathInterface) {
            $segment = new self($segment);
        }
        $segment = $this->decodeComponent((string) $segment);
        if ($segment === $this->segments[$key]) {
            return $this;
        }
        $segments = $this->segments;
        $segments[$key] = $segment;
        if ($this->isAbsolute()) {
            \array_unshift($segments, '');
        }
        return new self(\implode(self::SEPARATOR, $segments));
    }
    /**
     * {@inheritDoc}
     */
    public function withoutEmptySegments() : \GFPDF_Vendor\League\Uri\Contracts\SegmentedPathInterface
    {
        return new self(\preg_replace(',/+,', self::SEPARATOR, $this->__toString()));
    }
    /**
     * {@inheritDoc}
     */
    public function withoutSegment(int ...$keys) : \GFPDF_Vendor\League\Uri\Contracts\SegmentedPathInterface
    {
        if ([] === $keys) {
            return $this;
        }
        $nb_segments = \count($this->segments);
        $options = ['options' => ['min_range' => -$nb_segments, 'max_range' => $nb_segments - 1]];
        $deleted_keys = [];
        foreach ($keys as $value) {
            /** @var false|int $offset */
            $offset = \filter_var($value, \FILTER_VALIDATE_INT, $options);
            if (\false === $offset) {
                throw new \GFPDF_Vendor\League\Uri\Exceptions\OffsetOutOfBounds(\sprintf('The key `%s` is invalid.', $value));
            }
            if ($offset < 0) {
                $offset += $nb_segments;
            }
            $deleted_keys[] = $offset;
        }
        $deleted_keys = \array_keys(\array_count_values($deleted_keys));
        $filter = static function ($key) use($deleted_keys) : bool {
            return !\in_array($key, $deleted_keys, \true);
        };
        $path = \implode(self::SEPARATOR, \array_filter($this->segments, $filter, \ARRAY_FILTER_USE_KEY));
        if ($this->isAbsolute()) {
            return new self(self::SEPARATOR . $path);
        }
        return new self($path);
    }
    /**
     * @param mixed|string $path
     */
    public function withDirname($path) : \GFPDF_Vendor\League\Uri\Contracts\SegmentedPathInterface
    {
        if (!$path instanceof \GFPDF_Vendor\League\Uri\Contracts\PathInterface) {
            $path = new \GFPDF_Vendor\League\Uri\Components\Path($path);
        }
        if ($path->getContent() === $this->getDirname()) {
            return $this;
        }
        return new self(\rtrim($path->__toString(), self::SEPARATOR) . self::SEPARATOR . \array_pop($this->segments));
    }
    /**
     * {@inheritDoc}
     */
    public function withBasename($basename) : \GFPDF_Vendor\League\Uri\Contracts\SegmentedPathInterface
    {
        $basename = $this->validateComponent($basename);
        if (null === $basename) {
            throw new \GFPDF_Vendor\League\Uri\Exceptions\SyntaxError('A basename sequence can not be null.');
        }
        if (\false !== \strpos($basename, self::SEPARATOR)) {
            throw new \GFPDF_Vendor\League\Uri\Exceptions\SyntaxError('The basename can not contain the path separator.');
        }
        return $this->withSegment(\count($this->segments) - 1, $basename);
    }
    /**
     * {@inheritDoc}
     */
    public function withExtension($extension) : \GFPDF_Vendor\League\Uri\Contracts\SegmentedPathInterface
    {
        $extension = $this->validateComponent($extension);
        if (null === $extension) {
            throw new \GFPDF_Vendor\League\Uri\Exceptions\SyntaxError('An extension sequence can not be null.');
        }
        if (\false !== \strpos($extension, self::SEPARATOR)) {
            throw new \GFPDF_Vendor\League\Uri\Exceptions\SyntaxError('An extension sequence can not contain a path delimiter.');
        }
        if (0 === \strpos($extension, '.')) {
            throw new \GFPDF_Vendor\League\Uri\Exceptions\SyntaxError('An extension sequence can not contain a leading `.` character.');
        }
        /** @var string $basename */
        $basename = \end($this->segments);
        [$ext, $param] = \explode(';', $basename, 2) + [1 => null];
        if ('' === $ext) {
            return $this;
        }
        return $this->withBasename($this->buildBasename($extension, (string) $ext, $param));
    }
    /**
     * Creates a new basename with a new extension.
     */
    private function buildBasename(string $extension, string $ext, string $param = null) : string
    {
        $length = \strrpos($ext, '.' . \pathinfo($ext, \PATHINFO_EXTENSION));
        if (\false !== $length) {
            $ext = \substr($ext, 0, $length);
        }
        if (null !== $param && '' !== $param) {
            $param = ';' . $param;
        }
        $extension = \trim($extension);
        if ('' === $extension) {
            return $ext . $param;
        }
        return $ext . '.' . $extension . $param;
    }
}
